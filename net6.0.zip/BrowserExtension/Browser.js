var ListYTBLink = null;
var url = "http://localhost";
var videoIndex = 0;
var alarmName = "Auto";

function doSomething(body)
{
    console.log(body);
}

 async function getTabId()
  {
    let queryOptions = { active: true, lastFocusedWindow: true };
  // `tab` will either be a `tabs.Tab` instance or `undefined`.
    let [tab] = await chrome.tabs.query(queryOptions);
    return tab.id;
  }

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}
async function createAlarm() {
    chrome.alarms.create(alarmName, {
        
     periodInMinutes: 0.2});
      chrome.alarms.onAlarm.addListener(function(alarm) {
         main();
        console.log("runing in main");
      });
  }
  createAlarm();
 // chrome.runtime.onStartup.addListener
async function main() {

    chrome.tabs.query({}, function (tabs) {
        for (var i = 0; i < tabs.length - 1; i++) {
            chrome.tabs.remove(tabs[i].id);
        }
    });

    var GetFile = await fetch("http://localhost" + "/getLink").then((Respone) => Respone.text()).then((value) => {
        ListYTBLink = value.split('\n');
        console.log(value);
    });
                    
                    if (ListYTBLink != null)
                    {
                        if (ListYTBLink.length <= videoIndex) videoIndex = 0;
                        const tabId =await getTabId();
   
                        chrome.tabs.create(
                            {
                                url :  ListYTBLink[videoIndex]
                            }
                        );
                        videoIndex++;
                    }
                       
}
       
        

