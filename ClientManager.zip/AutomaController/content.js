function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}
async function GetHostWorkFlow()
{
    window.location.href = "chrome-extension://infppggnoaenmfagbfknfkancpbljcca/newtab.html#/workflows"
    var buttonTrianagle = document.getElementsByClassName('ui-button relative h-10 transition bg-accent hover:bg-gray-700 dark:bg-gray-100 dark:hover:bg-gray-200 dark:text-black text-white p-2 rounded-lg rounded-l-none rounded-l-none')[0];
    buttonTrianagle.click();
    await sleep(1000);
    var AddWorkFlow = document.getElementsByClassName("ui-list-item flex w-full items-center rounded-lg transition focus:outline-none hoverable py-2 px-4 cursor-pointer")[2];
    AddWorkFlow.click();
   await sleep(1000);
 await  ChangeInputvalue();
    var SummitBtn = document.getElementsByClassName('ui-button relative h-10 transition bg-accent hover:bg-gray-700 dark:bg-gray-100 dark:hover:bg-gray-200 dark:text-black text-white py-2 px-4 rounded-lg w-6/12 w-6/12')[0];
    Click(SummitBtn);
}
async function ChangeInputvalue()
{
    var inputEl = document.getElementsByTagName('input')[1];
    inputEl.focus();
    while (inputEl.value === '')
    {
        inputEl = document.getElementsByTagName('input')[1];
        inputEl.value = "ddđ";
        console.log( document.getElementsByTagName('input')[1].value );
        await sleep(3000);
    }
}
GetHostWorkFlow();
function Click(element)
{
    // Select the element you want to simulate the event on


// Create a new click event
const clickEvent = new Event('click', { bubbles: true });


element.dispatchEvent(clickEvent);

}