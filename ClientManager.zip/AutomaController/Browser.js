var ip ='http://localhost:4433'
var local = "http://localhost:26814/"
async function Main() {
    chrome.tabs.onCreated.addListener(function (tab) {
        chrome.tabs.update(tab.id, { muted: true });
        chrome.tabs.query({}, function (tabs) {
            for (var i = 0; i < tabs.length - 3; i++) {
                chrome.tabs.remove(tabs[i].id);
            }
        });
    });
  await getClientId();
    function sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    var Clientid;
    // Get CLient id from the server
   async function getClientId() {
        
        var res;
       await fetch(local + "getClientID")
            .then(response => response.text())
            .then(value => {
                res = parseInt(value);
            });
       Clientid = res;
    }

    function fetchAndAddCookies(ServerIp) {
        return fetch(ServerIp + "/GetGGCookie/" + Clientid)
            .then(response => response.text())
            .then(cookies => {
                console.log(cookies);
                cookies.split(';').forEach(cookie => {
                    const cookieParts = cookie.split('=');
                    const name = cookieParts[0].trim();
                    const value = cookieParts[1].trim();
                   
                    chrome.cookies.set({ url: "https://www.youtube.com", name, value, domain: ".youtube.com", secure : name.includes("__Secure") }, () => { });
                });
            })
            .catch(error => console.error(error));
    }
    fetchAndAddCookies(ip)
    async function ReDo(action) {

        while (true) {
            try {
                await sleep(1000);
                action();
                console.log("sucess");
                break;
            }
            catch {

            }
        }
    }
    function SetSwitchTabs() {
        let currentTab = 0;
        let tabCount = 0; // number of tabs
        chrome.tabs.query({ currentWindow: true }, function (tabs) {
            tabCount = tabs.length; // set tabCount to number of tabs available
        });

        function switchTab() {
            currentTab = (currentTab + 1) % tabCount; // loop through tabs
            chrome.tabs.query({ currentWindow: true }, function (tabs) {
                chrome.tabs.update(tabs[currentTab].id, { active: true }); // switch to next tab
            });
        }

        setInterval(switchTab, 30000); // call switchTab function every 10 seconds

    }
    SetSwitchTabs();
    function StartSendBrowserStat() {
        function SendBrowserStat() {
            try { fetch(local + "check"); }
            catch {   }
        }
        setInterval(SendBrowserStat,1000);
    }
    StartSendBrowserStat();
}
Main();
