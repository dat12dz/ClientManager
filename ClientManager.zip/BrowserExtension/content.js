﻿
(async () => {
    await new Promise(r => setTimeout(r, 3000));
    document.querySelector('#search-form > #container').click();
    while (true) {
        var video = document.getElementsByTagName('video')[0];
/*        document.getElementsByTagName('video')[0].addEventListener('click', () => {
            document.getElementsByTagName('video')[0].play();
        })
        document.getElementsByTagName('video')[0].click();*/
        await new Promise(r => setTimeout(r, 10000));
        console.log("Play");
    }
}
)();