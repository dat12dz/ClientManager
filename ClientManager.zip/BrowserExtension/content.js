﻿
function ScriptLoader(jsDir) {
  
    const script = document.createElement('script');
    script.setAttribute("type", "module");
    script.setAttribute("src", chrome.runtime.getURL(jsDir));
    const head = document.head || document.getElementsByTagName("head")[0] || document.documentElement;
    head.insertBefore(script, head.lastChild);
}
ScriptLoader("comment-list.js");

function CheckYtbStat() {
    var a  = new URLSearchParams(window.location.search)
    if (a.has('search_query')) {
       return 1
    }
    if (a.has('v')) {
        return 2
    }
    return 0
}
async function EnterFirstVideo() {

    var video = null;
    video = document.getElementsByTagName('ytd-video-renderer')[0].querySelector('img');
    video.click();
    console.log(video);
 
    
}
// handle Message from service worker

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {

    var MessageSplited = request.command;
    switch (MessageSplited) {
        case 'Play':
            if (CheckYtbStat() == 0)
                SearchVideo(request.data, SearchBar, SearchBtn);
            break;
    }
    sendResponse('This is the content script!');

   
});
function CommentTyping(text,delay) {
    let index = 0;
    const typingInterval = setInterval(() => {
        document.activeElement.innerHTML += text[index];
        index++;
        if (index === text.length) {
            clearInterval(typingInterval);D
            document.activeElement.dispatchEvent(new KeyboardEvent("keydown", {
                bubbles: true,
                cancelable: true,
                key: "Enter",
                ctrlKey: true
            }));
        }
    }, delay);
}
// ChatGPT
function smoothScrollTo(target) {
    // Get the current position
    var currentPosition = window.pageYOffset;
   
    // Calculate the step size
    var step = (target - currentPosition) / 50;

    // Scroll animation function
    function scroll() {
        // Stop the animation when the target is reached
        if (Math.abs(currentPosition - target) < 1) return;

        // Update the current position
        currentPosition += step;

        // Scroll to the new position
        window.scrollTo(0, currentPosition);

        // Request the next animation frame
        window.requestAnimationFrame(scroll);
    }

    // Start the scroll animation
    window.requestAnimationFrame(scroll);
}
function typeIntoDiv(QueryString, text) {
    // Get the contenteditable div element
    var divElement = document.querySelector(QueryString);

    // A counter to keep track of the current position in the text
    var i = 0;

    // A function to simulate typing
    function type() {
        // Stop when all the text has been typed
        if (i < text.length) {
            // Append the next character
            divElement.innerHTML += text[i];

            // Increment the counter
            i++;

            // Wait a little before typing the next character
            setTimeout(type, 50);
        }
    }

    // Start typing
    type();
}
async function ScrollNWait()
{
    while (true) {
        await Sleep(getRndInteger(0, 5 * 60));
        smoothScrollTo(500);
        await Sleep(getRndInteger(0, 5 * 60));
        smoothScrollTo(-500);
    }
}
async function Sleep(sec) {
  return new Promise(r => setTimeout(r, sec * 1000));
}
function getRndInteger(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
}
(async () => {
    function sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    var AllPerForm = false;
    while (true) {
        try {
            await sleep(2000);
            if (CheckYtbStat() == 1)
                EnterFirstVideo();
            if (CheckYtbStat() == 2 && !AllPerForm) {
               
                LikeVideo();
                cmtVideo();
                SubVideo();

                document.querySelector('#search-form > #container').click();
                main();
                ScrollNWait();
                AllPerForm = true;
            }
        }
        catch { }
        await sleep(3000);
    }
}
)()
async function main() {
    while (true) {
        var video = document.getElementsByTagName('video')[0];
        /*        document.getElementsByTagName('video')[0].addEventListener('click', () => {
                    document.getElementsByTagName('video')[0].play();
                })
                document.getElementsByTagName('video')[0].click();*/

        await new Promise(r => setTimeout(r, 10000));
        console.log("Play");

    }
}
var LikeBtn = "#segmented-like-button .yt-spec-touch-feedback-shape__fill"; 
var SubBtn = "#subscribe-button .yt-spec-touch-feedback-shape__fill";
var CmtLineBtn = "#placeholder-area";
var SearchBar = "#search-input > #search";
var SearchBtn = 'button#search-icon-legacy';
function SearchVideo(text, inputSelector, buttonSelector) {
    // Get the text input element
    console.log(text);
    const input = document.querySelector(inputSelector);

    // Get the button element
    const button = document.querySelector(buttonSelector);

    let i = 0;
    input.value = '';
    // Function to simulate a key press event
    function type() {
        // Add the next character to the input field
        input.value += text[i];
        i++;

        // If all characters have been typed, stop and simulate a click on the button
        if (i == text.length) {
         
            clearInterval(typingInterval);
            button.dispatchEvent(new MouseEvent('click', { bubbles: true }));
            
        }
    }

    // Start the typing interval
    const typingInterval = setInterval(type, 50);
}

async function LikeVideo() { 
   
    ClickBtnWithRateAndWait(LikeBtn, 40);
}
async function SubVideo()
{
    ClickBtnWithRateAndWait(SubBtn, 20);
}
async function cmtVideo()
{
    var IsCmt = await ClickBtnWithRateAndWait(CmtLineBtn, 100);
    if (IsCmt) {
        document.querySelector(CmtLineBtn).click();
        CommentTyping("Xin chao",200);
    }
}
async function ClickBtnWithRateAndWait(element, Inprate) {
    console.log(element + ": Start waiting")
    var rate = getRndInteger(0, 100);
    if (rate < Inprate) {
        var WaitToClick = getRndInteger(0, 10 * 60);
       await Sleep(WaitToClick);
        document.querySelector(element).click();
        console.log(element + ": Clicked");
        
    }
    else {
        console.log(element + ": Not click");
    }
    return rate < Inprate;
}