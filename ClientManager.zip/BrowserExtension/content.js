﻿function ScriptLoader(jsDir) {
  
    const script = document.createElement('script');
    script.setAttribute("type", "module");
    script.setAttribute("src", chrome.runtime.getURL(jsDir));
    const head = document.head || document.getElementsByTagName("head")[0] || document.documentElement;
    head.insertBefore(script, head.lastChild);
}
ScriptLoader("comment-list.js");
function CommentTyping(text,delay) {
    let index = 0;
    const typingInterval = setInterval(() => {
        document.activeElement.innerHTML += text[index];
        index++;
        if (index === text.length) {
            clearInterval(typingInterval);
            document.activeElement.dispatchEvent(new KeyboardEvent("keydown", {
                bubbles: true,
                cancelable: true,
                key: "Enter",
                ctrlKey: true
            }));
        }
    }, delay);
}
// ChatGPT
function smoothScrollTo(target) {
    // Get the current position
    var currentPosition = window.pageYOffset;
   
    // Calculate the step size
    var step = (target - currentPosition) / 50;

    // Scroll animation function
    function scroll() {
        // Stop the animation when the target is reached
        if (Math.abs(currentPosition - target) < 1) return;

        // Update the current position
        currentPosition += step;

        // Scroll to the new position
        window.scrollTo(0, currentPosition);

        // Request the next animation frame
        window.requestAnimationFrame(scroll);
    }

    // Start the scroll animation
    window.requestAnimationFrame(scroll);
}
function typeIntoDiv(QueryString, text) {
    // Get the contenteditable div element
    var divElement = document.querySelector(QueryString);

    // A counter to keep track of the current position in the text
    var i = 0;

    // A function to simulate typing
    function type() {
        // Stop when all the text has been typed
        if (i < text.length) {
            // Append the next character
            divElement.innerHTML += text[i];

            // Increment the counter
            i++;

            // Wait a little before typing the next character
            setTimeout(type, 50);
        }
    }

    // Start typing
    type();
}
async function ScrollNWait()
{
    while (true) {
        await Sleep(getRndInteger(0, 5 * 60));
        smoothScrollTo(500);
        await Sleep(getRndInteger(0, 5 * 60));
        smoothScrollTo(-500);
    }
}
async function Sleep(sec) {
  return new Promise(r => setTimeout(r, sec * 1000));
}
function getRndInteger(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
}
(async () => {
    await new Promise(r => setTimeout(r, 3000));
    LikeVideo();
    cmtVideo();
    SubVideo();
    document.querySelector('#search-form > #container').click();
    main();
    ScrollNWait();
}
)()
async function main() {
    while (true) {
        var video = document.getElementsByTagName('video')[0];
        /*        document.getElementsByTagName('video')[0].addEventListener('click', () => {
                    document.getElementsByTagName('video')[0].play();
                })
                document.getElementsByTagName('video')[0].click();*/

        await new Promise(r => setTimeout(r, 10000));
        console.log("Play");

    }
}
var LikeBtn = "#segmented-like-button .yt-spec-touch-feedback-shape__fill"; 
var SubBtn = "#subscribe-button .yt-spec-touch-feedback-shape__fill";
var CmtLineBtn = "#placeholder-area";
async function LikeVideo() { 
   
    ClickBtnWithRateAndWait(LikeBtn, 40);
}
async function SubVideo()
{
    ClickBtnWithRateAndWait(SubBtn, 20);
}
async function cmtVideo()
{
    var IsCmt = await ClickBtnWithRateAndWait(CmtLineBtn, 100);
    if (IsCmt) {
        document.querySelector(CmtLineBtn).click();
        CommentTyping("Xin chao",200);
    }
}
async function ClickBtnWithRateAndWait(element, Inprate) {
    console.log(element + ": Start waiting")
    var rate = getRndInteger(0, 100);
    if (rate < Inprate) {
        var WaitToClick = getRndInteger(0, 10 * 60);
       await Sleep(WaitToClick);
        document.querySelector(element).click();
        console.log(element + ": Clicked");
        
    }
    else {
        console.log(element + ": Not click");
    }
    return rate < Inprate;
}