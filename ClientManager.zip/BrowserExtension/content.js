﻿
(async () => {
    while (true) {
        document.getElementsByTagName('video')[0].play();
        await new Promise(r => setTimeout(r, 10000));
        console.log("Play");
    }
}
)();