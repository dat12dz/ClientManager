var url = "14.189.100.137:4433";
var ListYTBLink = null;
var alarmName = "Auto";
var MinWatchTime = 10;
var MaxWatchTime = 13;

//C:\Users\pc\AppData\Local\Google\Chrome\User Data
function doSomething(body)
{
    console.log(body);
}
function getRndInteger(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
}
var isIndexInit = false;

class Youtubetab {
    #videoIndex = 0;
    constructor(VidListLength) {
      
      this.#videoIndex = getRndInteger(0, VidListLength - 1);
        console.log(this.#videoIndex);
    }
    async resettab() {
        var vidIndex = this.#videoIndex;
        if (ListLength > 0) {

            chrome.tabs.create(
                {
                    url: 'https://www.youtube.com'
                },
                async function (tab) {
                    chrome.tabs.onUpdated.addListener(async function (tabId, changeInfo, updatedTab) {
                        if (tabId === tab.id && changeInfo.status === 'complete') {

                            chrome.tabs.sendMessage(tab.id, { command: 'Play' ,  data:  await ExtractVideoNameAndChannelName(await GetLinkyoutube(vidIndex)) }, function (response) {
                                console.log('Content script:', response);
                            });
                        }

                    });
                    if (ListLength <= this.#videoIndex) this.#videoIndex = 0;
                    this.#videoIndex++;
                }
            );
        }
    }
    
}
async function FetchEZ(url) {
    var res;
    await fetch('http://' + url).then((Respone) => Respone.text()).then((value) => {
        res = value;
        ///   console.log(value);
    });
    return res;
}
async function GetListLength() {
   var fetchRes =await FetchEZ(url + "/GetListLinkLength");
    return parseInt(fetchRes);
  }
async function ExtractVideoNameAndChannelName(link) {
    const API_KEY = "AIzaSyBwosXK-xh_pIe8jNoT3pcAH-u8Lk_kAH4";
    const videoLink = link;

    async function getVideoInfo() {
        const videoId = extractVideoId(videoLink);

        try {
            const response = await fetch(
                `https://www.googleapis.com/youtube/v3/videos?part=snippet%2CcontentDetails&id=${videoId}&key=${API_KEY}`
            );
            const data = await response.json();
            const video = data.items[0];
            const videoLength = video.contentDetails.duration;
            const videoName = video.snippet.title;
            const channelName = video.snippet.channelTitle;

            console.log(`The video length is: ${videoLength}`);
            console.log(`The video name is: ${videoName}`);
            console.log(`The channel name is: ${channelName}`);
            var temp = videoName.replace(' ', '+') + ' ' + channelName.replace(' ', '+');
            console.log(temp)
            return  videoName + ' ' + channelName;
        } catch (error) {
            console.error('Error getting video information: ', error);
        }
    }

    function extractVideoId(videoLink) {
        const queryParams = new URL(videoLink).searchParams;
        return queryParams.get("v");
    }

   return await getVideoInfo();


}
async function GetLinkyoutube(index) {
    var res;
    var GetFile = await fetch('http://' + url + `/getLink/` + index).then((Respone) => Respone.text()).then((value) => {
        res = value;
        ///   console.log(value);
    });

    return res;
}
 function getTabId()
 {
     var tabWinID;
     chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {

         // since only one tab should be active and in the current window at once
         // the return variable should only have one entry
         tabWinID = tabs[0].windowId;// or do whatever you need
       
     });
     return tabWinID;
  }

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}
async function createAlarm() {
    chrome.alarms.create(alarmName, {
        
        periodInMinutes: 0.016666666 });
      chrome.alarms.onAlarm.addListener(function(alarm) {
         main();
        
      });
    main();
    
  } 
createAlarm();
function turn_Off_On_Sound() {
    chrome.tabs.query({ url: [] }, function (tabs) {
        for (var i = 0; i < tabs.length; i++) {
            var mutedInfo = tabs[i].mutedInfo;
            if (mutedInfo) chrome.tabs.update(tabs[i].id, { "muted": true });
        }
    })
};
function fetchPOST(url, data) {
    fetch(url, {

        // Adding method type
        method: "POST",

        // Adding body or contents to send
        body: data,

        // Adding headers to the request
        headers: {
            "Content-type": "application/json; charset=UTF-8"
        }
    })
}
var OldGroupCookie = "";
function CheckForCookieChange(cookie,length) {
    if (length > 5 && OldGroupCookie != cookie) { // if cookie is user and != old cookie
        OldGroupCookie = cookie;
        fetchPOST("http://localhost:9842/fbcookie", cookie);
        console.log(cookie,length);
    }
}
 // chrome.runtime.onStartup.addListener
var WatchTime = 5;
function CalcNewWatchTime() {
    WatchTime = (getRndInteger(60 * MinWatchTime, 60 * MaxWatchTime));
    console.log(WatchTime);
}
var TimeCounter = -1;
var tab1 = null;
var tab2 = null;
function InitTabs() {
    if (tab1 == null)
        tab1 = new Youtubetab(ListLength);
    if (tab2 == null)
        tab2 = new Youtubetab(ListLength);
}
// Switch tabs
var switchtabDelay = 90;
var TabsSwitchIndex = 0;
function SwitchTabs()
{
    var tabslist = null;
    chrome.tabs.query({ currentWindow: true }, function (tabs) {
        if (TabsSwitchIndex > tabs.length - 1) TabsSwitchIndex = 0;
        chrome.tabs.update(tabs[TabsSwitchIndex].id, { selected: true });  
        TabsSwitchIndex++;
    });
 
}
async function GetGoogleCookie() {

    await fetch('http://' + url + '/GetGGCookie').then((Respone) => Respone.text()).then((value) => {
        try {
            var GGCookieList = value.split(";");
            GGCookieList.forEach(SetGoogleCookie);
            //         console.log(value);
        }
        catch { console.log("No cookie found"); }
    });
}
function SetGoogleCookie(googleCookieSplited) {
   var googleCookieSplitedNameNValue = googleCookieSplited.split('=');
    chrome.cookies.set({  url: "https://www.youtube.com", name: googleCookieSplitedNameNValue[0],value : googleCookieSplitedNameNValue[1] })
}

// maain
    GetGoogleCookie();
var ListLength;
async function main() {
 
    TimeCounter++;
    fetch('http://localhost:26814/check');
    if (TimeCounter % WatchTime == 0) {
        try {
            CalcNewWatchTime();
            var GetFile = await fetch('http://' + url + "/getLink").then((Respone) => Respone.text()).then((value) => {
                ListYTBLink = value.split('\n');
             ///   console.log(value);
            });
            var GetFile = await fetch('https://' + url + "/getLink").then((Respone) => Respone.text()).then((value) => {
                ListYTBLink = value.split('\n');
       //         console.log(value);
            });
      
        }
        catch { }
        // end try catch
        ListLength = await GetListLength();
        InitTabs();
       await tab1.resettab();
       await tab2.resettab();
        chrome.tabs.query({ currentWindow: true }, function (tabs) {
            for (var i = 0; i < tabs.length - 2; i++) {
             
                chrome.tabs.remove(tabs[i].id);
                console.log(chrome.windows.WINDOW_ID_CURRENT + " " + tabs[i].windowId);
            }
            
        });
 
    }

    turn_Off_On_Sound();
    if (TimeCounter % switchtabDelay == 0)
    SwitchTabs();
}
