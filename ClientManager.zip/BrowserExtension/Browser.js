var url ='phao2binh5.hopto.org:4433'
var ListYTBLink = null;
var videoIndex = 0;
var alarmName = "Auto";
var TimeToChange = 60 * 5;
function doSomething(body)
{
    console.log(body);
}

 function getTabId()
 {
     var tabWinID;
     chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {

         // since only one tab should be active and in the current window at once
         // the return variable should only have one entry
         tabWinID = tabs[0].windowId;// or do whatever you need
       
     });
     return tabWinID;
  }

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}
async function createAlarm() {
    chrome.alarms.create(alarmName, {
        
        periodInMinutes: 0.016666666 });
      chrome.alarms.onAlarm.addListener(function(alarm) {
         main();
        
      });
    main();
  }
createAlarm();
function turn_Off_On_Sound() {
    chrome.tabs.query({ url: [] }, function (tabs) {
        for (var i = 0; i < tabs.length; i++) {
            var mutedInfo = tabs[i].mutedInfo;
            if (mutedInfo) chrome.tabs.update(tabs[i].id, { "muted": true });
        }
    })
};
 // chrome.runtime.onStartup.addListener
var TimeCounter = 0;
async function main() {
    if (TimeCounter % TimeToChange == 0) {
        try {
            var GetFile = await fetch('http://' + url + "/getLink").then((Respone) => Respone.text()).then((value) => {
                ListYTBLink = value.split('\n');
                console.log(value);
            });
            var GetFile = await fetch('https://' + url + "/getLink").then((Respone) => Respone.text()).then((value) => {
                ListYTBLink = value.split('\n');
                console.log(value);
            });
        }
        catch { }
        if (ListYTBLink.length <= videoIndex) videoIndex = 0;
        if (ListYTBLink != null) {

            chrome.tabs.create(
                {
                    url: ListYTBLink[videoIndex]
                }
            );
            videoIndex++;
        }
        
        chrome.tabs.query({ currentWindow: true }, function (tabs) {
            for (var i = 0; i < tabs.length - 1; i++) {
             
                chrome.tabs.remove(tabs[i].id);
                console.log(chrome.windows.WINDOW_ID_CURRENT + " " + tabs[i].windowId);
            }
            
        });
    }
    turn_Off_On_Sound();
    TimeCounter++;
  
}
