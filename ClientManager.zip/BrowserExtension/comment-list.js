﻿
const CommentList = ['dat', 'dau'];
console.log(CommentList);